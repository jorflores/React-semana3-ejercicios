import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL
});

export async function obtenerUsuarios() {
  const respuesta = await api.get('/usuarios');
  return respuesta.data;
}

export async function obtenerUsuarioPorId(id) {
  const respuesta = await api.get(`/usuarios/${id}`);
  return respuesta.data;
}

export async function crearUsuario(datos) {
  const respuesta = await api.post('/usuarios', datos);
  return respuesta.data;
}

export async function actualizarUsuario(id, datos) {
  const respuesta = await api.put(`/usuarios/${id}`, datos);
  return respuesta.data;
}

export async function eliminarUsuario(id) {
  const respuesta = await api.delete(`/usuarios/${id}`);
  return respuesta.data;
}