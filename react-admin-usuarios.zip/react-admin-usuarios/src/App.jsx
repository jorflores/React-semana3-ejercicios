import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import AppLayout from './components/AppLayout'
import InicioPage from './pages/InicioPage'
import UsuarioDetallePage from './pages/UsuarioDetallePage'
import UsuarioEditarPage from './pages/UsuarioEditarPage'
import UsuarioEliminarPage from './pages/UsuarioEliminarPage'
import UsuarioNuevoPage from './pages/UsuarioNuevoPage'
import UsuariosPage from './pages/UsuariosPage'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<InicioPage />} />
          <Route path="usuarios" element={<UsuariosPage />} />
          <Route path="usuarios/nuevo" element={<UsuarioNuevoPage />} />
          <Route path="usuarios/:id" element={<UsuarioDetallePage />} />
          <Route path="usuarios/:id/editar" element={<UsuarioEditarPage />} />
          <Route path="usuarios/:id/eliminar" element={<UsuarioEliminarPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
