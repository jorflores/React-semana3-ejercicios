import { Link } from 'react-router-dom'

function InicioPage() {
  return (
    <section className="grid gap-6">
      <div className="rounded-2xl border border-stone-200 bg-white p-8 shadow-sm">
        <p className="mb-2 text-xs font-bold uppercase tracking-widest text-brand">
          Frontend + API REST
        </p>
        <h2 className="mb-3 text-4xl font-semibold text-ink">
          Administracion de usuarios
        </h2>
        <p className="text-muted">
          Este proyecto ya tiene las rutas y pantallas principales. Durante la
          practica se agregaran las llamadas al API de Express, Sequelize y Neon.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Link
          className="grid gap-2 rounded-2xl border border-stone-200 bg-white p-6 text-inherit no-underline shadow-sm transition hover:-translate-y-0.5 hover:border-brand"
          to="/usuarios"
        >
          <span className="text-sm font-bold text-brand">01</span>
          <h3 className="text-lg font-semibold text-ink">Mostrar usuarios</h3>
          <p className="text-sm text-muted">Pagina para consultar todos los usuarios del API.</p>
        </Link>

        <Link
          className="grid gap-2 rounded-2xl border border-stone-200 bg-white p-6 text-inherit no-underline shadow-sm transition hover:-translate-y-0.5 hover:border-brand"
          to="/usuarios/nuevo"
        >
          <span className="text-sm font-bold text-brand">02</span>
          <h3 className="text-lg font-semibold text-ink">Dar de alta</h3>
          <p className="text-sm text-muted">Formulario para crear un usuario nuevo.</p>
        </Link>
      </div>
    </section>
  )
}

export default InicioPage
