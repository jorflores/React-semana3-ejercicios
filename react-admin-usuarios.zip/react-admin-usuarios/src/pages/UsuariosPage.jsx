import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { obtenerUsuarios } from '../api/usuariosApi';

function UsuariosPage() {
  const [usuarios, setUsuarios] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function cargarUsuarios() {
      try {
        const datos = await obtenerUsuarios();
        setUsuarios(datos);
      } catch {
        setError('No se pudieron cargar los usuarios');
      } finally {
        setCargando(false);
      }
    }

    cargarUsuarios();
  }, []);

  return (
    <section className="grid gap-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-brand">
            GET /usuarios
          </p>
          <h2 className="text-3xl font-semibold text-ink">Usuarios</h2>
          <p className="mt-1 text-muted">
            Lista preparada para mostrar los usuarios que regrese el API.
          </p>
        </div>
        <Link
          className="inline-flex justify-center rounded-lg bg-brand px-4 py-3 font-bold text-white no-underline transition hover:bg-brand/90"
          to="/usuarios/nuevo"
        >
          Nuevo usuario
        </Link>
      </div>

      {cargando && (
        <div className="grid gap-3 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
          <h3 className="text-xl font-semibold text-ink">Cargando usuarios...</h3>
          <p className="text-muted">Espera mientras consultamos el API.</p>
        </div>
      )}

      {error && (
        <div className="grid gap-3 rounded-2xl border border-red-200 bg-red-50 p-6 shadow-sm">
          <h3 className="text-xl font-semibold text-red-700">Error</h3>
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {!cargando && !error && usuarios.length === 0 && (
        <div className="grid gap-3 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
          <h3 className="text-xl font-semibold text-ink">Aun no hay usuarios cargados</h3>
          <p className="text-muted">
            El API respondio correctamente, pero todavia no hay registros.
          </p>
        </div>
      )}

      {!cargando && !error && usuarios.length > 0 && (
        <div className="overflow-x-auto rounded-2xl border border-stone-200 bg-white shadow-sm">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="border-b border-stone-100 px-4 py-3 text-left text-sm uppercase text-muted">
                  ID
                </th>
                <th className="border-b border-stone-100 px-4 py-3 text-left text-sm uppercase text-muted">
                  Nombre
                </th>
                <th className="border-b border-stone-100 px-4 py-3 text-left text-sm uppercase text-muted">
                  Correo
                </th>
                <th className="border-b border-stone-100 px-4 py-3 text-left text-sm uppercase text-muted">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody>
              {usuarios.map((usuario) => (
                <tr key={usuario.id}>
                  <td className="border-b border-stone-100 px-4 py-3">{usuario.id}</td>
                  <td className="border-b border-stone-100 px-4 py-3">{usuario.nombre}</td>
                  <td className="border-b border-stone-100 px-4 py-3">{usuario.correo}</td>
                  <td className="flex flex-wrap gap-3 border-b border-stone-100 px-4 py-3">
                    <Link className="font-bold text-brand no-underline" to={`/usuarios/${usuario.id}`}>
                      Ver
                    </Link>
                    <Link className="font-bold text-brand no-underline" to={`/usuarios/${usuario.id}/editar`}>
                      Editar
                    </Link>
                    <Link className="font-bold text-brand no-underline" to={`/usuarios/${usuario.id}/eliminar`}>
                      Eliminar
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

export default UsuariosPage;