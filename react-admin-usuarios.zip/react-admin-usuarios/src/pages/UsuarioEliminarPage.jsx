import { Link, useNavigate, useParams } from 'react-router-dom'
import { eliminarUsuario } from '../api/usuariosApi'

function UsuarioEliminarPage() {
  const { id } = useParams()
  const navigate = useNavigate()

  async function handleDelete() {
    await eliminarUsuario(id)
    navigate('/usuarios')
  }

  return (
    <section className="grid gap-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-brand">
            DELETE /usuarios/{id}
          </p>
          <h2 className="text-3xl font-semibold text-ink">Eliminar usuario</h2>
          <p className="mt-1 text-muted">
            Pagina preparada para confirmar la eliminacion del usuario con id {id}.
          </p>
        </div>
        <Link
          className="inline-flex justify-center rounded-lg border border-stone-200 bg-white px-4 py-3 font-bold text-muted no-underline transition hover:border-brand hover:text-brand"
          to={`/usuarios/${id}`}
        >
          Volver
        </Link>
      </div>

      <div className="grid gap-4 rounded-2xl border border-red-200 bg-red-50 p-6 shadow-sm">
        <h3 className="text-xl font-semibold text-ink">Confirmar eliminacion</h3>
        <p className="text-muted">
          Cuando se conecte el API, este boton eliminara el registro en la base
          de datos.
        </p>
        <div className="flex flex-wrap gap-3">
          <button
            className="inline-flex justify-center rounded-lg bg-red-600 px-4 py-3 font-bold text-white transition hover:bg-red-700"
            type="button"
            onClick={handleDelete}
          >
            Eliminar usuario
          </button>
          <Link
            className="inline-flex justify-center rounded-lg border border-stone-200 bg-white px-4 py-3 font-bold text-muted no-underline transition hover:border-brand hover:text-brand"
            to="/usuarios"
          >
            Cancelar
          </Link>
        </div>
      </div>
    </section>
  )
}

export default UsuarioEliminarPage
