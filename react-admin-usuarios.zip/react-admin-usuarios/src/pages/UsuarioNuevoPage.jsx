import { Link, useNavigate } from 'react-router-dom'
import { crearUsuario } from '../api/usuariosApi'
import UsuarioForm from '../components/UsuarioForm'

function UsuarioNuevoPage() {
  const navigate = useNavigate()

  async function handleCrearUsuario(datos) {
    await crearUsuario(datos)
    navigate('/usuarios')
  }

  return (
    <section className="grid gap-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-brand">
            POST /usuarios
          </p>
          <h2 className="text-3xl font-semibold text-ink">Nuevo usuario</h2>
          <p className="mt-1 text-muted">Formulario preparado para dar de alta un usuario en el API.</p>
        </div>
        <Link
          className="inline-flex justify-center rounded-lg border border-stone-200 bg-white px-4 py-3 font-bold text-muted no-underline transition hover:border-brand hover:text-brand"
          to="/usuarios"
        >
          Volver
        </Link>
      </div>

      <UsuarioForm
        titulo="Datos del nuevo usuario"
        textoBoton="Guardar usuario"
        onSubmit={handleCrearUsuario}
      />
    </section>
  )
}

export default UsuarioNuevoPage
