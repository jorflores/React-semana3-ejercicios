import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { actualizarUsuario, obtenerUsuarioPorId } from '../api/usuariosApi'
import UsuarioForm from '../components/UsuarioForm'

function UsuarioEditarPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [usuario, setUsuario] = useState(null)
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function cargarUsuario() {
      try {
        const datos = await obtenerUsuarioPorId(id)
        setUsuario(datos)
      } catch {
        setError('No se pudo cargar el usuario')
      } finally {
        setCargando(false)
      }
    }

    cargarUsuario()
  }, [id])

  async function handleActualizarUsuario(datos) {
    await actualizarUsuario(id, datos)
    navigate(`/usuarios/${id}`)
  }

  return (
    <section className="grid gap-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-brand">
            PUT /usuarios/{id}
          </p>
          <h2 className="text-3xl font-semibold text-ink">Editar usuario</h2>
          <p className="mt-1 text-muted">Formulario preparado para modificar el usuario con id {id}.</p>
        </div>
        <Link
          className="inline-flex justify-center rounded-lg border border-stone-200 bg-white px-4 py-3 font-bold text-muted no-underline transition hover:border-brand hover:text-brand"
          to={`/usuarios/${id}`}
        >
          Volver
        </Link>
      </div>

      {cargando && (
        <div className="grid gap-3 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
          <h3 className="text-xl font-semibold text-ink">Cargando usuario...</h3>
          <p className="text-muted">Espera mientras consultamos el API.</p>
        </div>
      )}

      {error && (
        <div className="grid gap-3 rounded-2xl border border-red-200 bg-red-50 p-6 shadow-sm">
          <h3 className="text-xl font-semibold text-red-700">Error</h3>
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {!cargando && !error && usuario && (
        <UsuarioForm
          titulo="Actualizar datos del usuario"
          textoBoton="Guardar cambios"
          valoresIniciales={usuario}
          onSubmit={handleActualizarUsuario}
        />
      )}
    </section>
  )
}

export default UsuarioEditarPage
