import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { obtenerUsuarioPorId } from '../api/usuariosApi';

function UsuarioDetallePage() {
  const { id } = useParams();
  const [usuario, setUsuario] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function cargarUsuario() {
      try {
        const datos = await obtenerUsuarioPorId(id);
        setUsuario(datos);
      } catch {
        setError('No se pudo cargar el usuario');
      } finally {
        setCargando(false);
      }
    }

    cargarUsuario();
  }, [id]);

  return (
    <section className="grid gap-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-brand">
            GET /usuarios/{id}
          </p>
          <h2 className="text-3xl font-semibold text-ink">Detalle de usuario</h2>
          <p className="mt-1 text-muted">Ruta preparada para consultar el usuario con id {id}.</p>
        </div>
        <Link
          className="inline-flex justify-center rounded-lg border border-stone-200 bg-white px-4 py-3 font-bold text-muted no-underline transition hover:border-brand hover:text-brand"
          to="/usuarios"
        >
          Volver
        </Link>
      </div>

      {cargando && (
        <div className="grid gap-3 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
          <h3 className="text-xl font-semibold text-ink">Cargando usuario...</h3>
          <p className="text-muted">Espera mientras consultamos el API.</p>
        </div>
      )}

      {error && (
        <div className="grid gap-3 rounded-2xl border border-red-200 bg-red-50 p-6 shadow-sm">
          <h3 className="text-xl font-semibold text-red-700">Error</h3>
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {!cargando && !error && usuario ? (
        <div className="grid gap-4 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
          <p className="text-muted">
            <strong>ID:</strong> {usuario.id}
          </p>
          <p className="text-muted">
            <strong>Nombre:</strong> {usuario.nombre}
          </p>
          <p className="text-muted">
            <strong>Correo:</strong> {usuario.correo}
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              className="inline-flex justify-center rounded-lg border border-stone-200 bg-white px-4 py-3 font-bold text-muted no-underline transition hover:border-brand hover:text-brand"
              to={`/usuarios/${usuario.id}/editar`}
            >
              Editar
            </Link>
            <Link
              className="inline-flex justify-center rounded-lg bg-red-600 px-4 py-3 font-bold text-white no-underline transition hover:bg-red-700"
              to={`/usuarios/${usuario.id}/eliminar`}
            >
              Eliminar
            </Link>
          </div>
        </div>
      ) : null}

      {!cargando && !error && !usuario && (
        <div className="grid gap-3 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
          <h3 className="text-xl font-semibold text-ink">Usuario no encontrado</h3>
          <p className="text-muted">
            El API respondio correctamente, pero no regreso informacion para este id.
          </p>
        </div>
      )}
    </section>
  )
}

export default UsuarioDetallePage
