import { NavLink, Outlet } from 'react-router-dom'

function AppLayout() {
  const linkClass = ({ isActive }) =>
    [
      'rounded-full border px-4 py-2 text-sm font-medium transition',
      isActive
        ? 'border-brand bg-brand/10 text-brand'
        : 'border-stone-200 text-muted hover:border-brand hover:bg-brand/10 hover:text-brand',
    ].join(' ')

  return (
    <div className="min-h-screen">
      <header className="border-b border-stone-200 bg-white px-6 py-7 md:px-10">
        <div>
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-brand">
            React Admin Usuarios
          </p>
          <h1 className="mb-2 text-3xl font-semibold text-ink">Panel de usuarios</h1>
          <p className="text-muted">
            Esqueleto preparado para consumir el API REST de usuarios.
          </p>
        </div>

        <nav className="mt-6 flex flex-wrap gap-3">
          <NavLink className={linkClass} to="/">
            Inicio
          </NavLink>
          <NavLink className={linkClass} to="/usuarios">
            Usuarios
          </NavLink>
          <NavLink className={linkClass} to="/usuarios/nuevo">
            Nuevo usuario
          </NavLink>
        </nav>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-10 md:py-12">
        <Outlet />
      </main>
    </div>
  )
}

export default AppLayout
