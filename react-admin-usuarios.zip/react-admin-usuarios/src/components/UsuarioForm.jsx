import { useState } from 'react'

function UsuarioForm({ titulo, textoBoton, valoresIniciales, onSubmit }) {
  const [form, setForm] = useState(
    valoresIniciales || { nombre: '', correo: '' },
  )

  function handleChange(event) {
    const { name, value } = event.target
    setForm({ ...form, [name]: value })
  }

  function handleSubmit(event) {
    event.preventDefault()
    onSubmit(form)
  }

  return (
    <form
      className="grid gap-5 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm"
      onSubmit={handleSubmit}
    >
      <h2 className="text-xl font-semibold text-ink">{titulo}</h2>

      <label className="grid gap-2 font-semibold text-ink" htmlFor="nombre">
        Nombre
        <input
          className="rounded-lg border border-stone-200 px-4 py-3 font-normal outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10"
          id="nombre"
          name="nombre"
          type="text"
          placeholder="Ej. Ana Lopez"
          value={form.nombre}
          onChange={handleChange}
        />
      </label>

      <label className="grid gap-2 font-semibold text-ink" htmlFor="correo">
        Correo
        <input
          className="rounded-lg border border-stone-200 px-4 py-3 font-normal outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10"
          id="correo"
          name="correo"
          type="email"
          placeholder="ana@tec.mx"
          value={form.correo}
          onChange={handleChange}
        />
      </label>

      <button
        className="inline-flex justify-center rounded-lg bg-brand px-4 py-3 font-bold text-white transition hover:bg-brand/90"
        type="submit"
      >
        {textoBoton}
      </button>
    </form>
  )
}

export default UsuarioForm
