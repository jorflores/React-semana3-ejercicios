import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginForm from './components/LoginForm.jsx';
import RegistryForm from './components/RegistryForm.jsx';
import Perfil from './pages/Perfil.jsx';
import Home from './pages/Home.jsx';

function App() {
  // Verificamos si existe un token guardado en localStorage
  const token = localStorage.getItem('token');
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/registro" element={<RegistryForm />} />
        <Route
          path="/perfil"
          element={
            // Ruta protegida: si hay token puede entrar, si no regresa al login
            // IMPORTANTE: esta verificación es solo visual en el frontend
            // La verificación real la hace el middleware verificarToken en el backend
            token ? <Perfil /> : <Navigate to="/login" replace />
          }
        />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
