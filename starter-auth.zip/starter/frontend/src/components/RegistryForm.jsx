import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const apiBase = import.meta.env.VITE_API_URL;

export default function RegistryForm() {
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleRegister = async () => {
    setError('');
    try {
      await axios.post(`${apiBase}/api/auth/registro`, {
        nombre,
        email,
        password,
      });
      navigate('/login');
    } catch (err) {
      setError(err.response?.data?.error || 'Error de conexión');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-2xl bg-white/95 p-8 shadow-2xl shadow-indigo-500/10 ring-1 ring-white/10 backdrop-blur">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 text-center mb-1">
          Crear cuenta
        </h1>
        <p className="text-sm text-slate-500 text-center mb-8">
          Completa tus datos para registrarte
        </p>

        {error ? (
          <div
            className="mb-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 border border-red-100"
            role="alert"
          >
            {error}
          </div>
        ) : null}

        <div className="space-y-5">
          <div>
            <label
              htmlFor="reg-nombre"
              className="mb-1.5 block text-sm font-medium text-slate-700"
            >
              Nombre
            </label>
            <input
              id="reg-nombre"
              type="text"
              autoComplete="name"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
              placeholder="Tu nombre"
            />
          </div>
          <div>
            <label
              htmlFor="reg-email"
              className="mb-1.5 block text-sm font-medium text-slate-700"
            >
              Correo electrónico
            </label>
            <input
              id="reg-email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
              placeholder="tu@email.com"
            />
          </div>
          <div>
            <label
              htmlFor="reg-password"
              className="mb-1.5 block text-sm font-medium text-slate-700"
            >
              Contraseña
            </label>
            <input
              id="reg-password"
              type="password"
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
              placeholder="••••••••"
            />
          </div>
          <button
            type="button"
            onClick={handleRegister}
            className="w-full rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 py-3.5 font-semibold text-white shadow-lg shadow-indigo-500/30 transition hover:from-indigo-500 hover:to-violet-500 active:scale-[0.98]"
          >
            Registrarse
          </button>
        </div>

        <p className="mt-8 text-center text-sm text-slate-600">
          ¿Ya tienes cuenta?{' '}
          <Link
            to="/login"
            className="font-semibold text-indigo-600 hover:text-indigo-500"
          >
            Inicia sesión
          </Link>
        </p>
      </div>
    </div>
  );
}
