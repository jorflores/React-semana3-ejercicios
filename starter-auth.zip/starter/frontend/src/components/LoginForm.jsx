import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    setError('');
    try {
      // 1. Enviamos las credenciales al backend
      const res = await axios.post(
        import.meta.env.VITE_API_URL + '/api/auth/login',
        { email, password }
      );

      // 2. El backend responde con { token } si las credenciales son correctas
      // 3. Guardamos el token en localStorage para usarlo en rutas protegidas
      localStorage.setItem('token', res.data.token);

      // 4. Redirigimos al usuario a su perfil
      navigate('/perfil');
    } catch (err) {
      setError(err.response?.data?.error || 'Error de conexión');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-2xl bg-white/95 p-8 shadow-2xl shadow-indigo-500/10 ring-1 ring-white/10 backdrop-blur">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 text-center mb-1">
          Iniciar sesión
        </h1>
        <p className="text-sm text-slate-500 text-center mb-8">
          Accede con tu correo y contraseña
        </p>

        {error ? (
          <div
            className="mb-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 border border-red-100"
            role="alert"
          >
            {error}
          </div>
        ) : null}

        <div className="space-y-5">
          <div>
            <label
              htmlFor="login-email"
              className="mb-1.5 block text-sm font-medium text-slate-700"
            >
              Correo electrónico
            </label>
            <input
              id="login-email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
              placeholder="tu@email.com"
            />
          </div>
          <div>
            <label
              htmlFor="login-password"
              className="mb-1.5 block text-sm font-medium text-slate-700"
            >
              Contraseña
            </label>
            <input
              id="login-password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-slate-900 outline-none transition focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
              placeholder="••••••••"
            />
          </div>
          <button
            type="button"
            onClick={handleLogin}
            className="w-full rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 py-3.5 font-semibold text-white shadow-lg shadow-indigo-500/30 transition hover:from-indigo-500 hover:to-violet-500 active:scale-[0.98]"
          >
            Entrar
          </button>
        </div>

        <p className="mt-8 text-center text-sm text-slate-600">
          ¿No tienes cuenta?{' '}
          <Link
            to="/registro"
            className="font-semibold text-indigo-600 hover:text-indigo-500"
          >
            Regístrate
          </Link>
        </p>
      </div>
    </div>
  );
}
