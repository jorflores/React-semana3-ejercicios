import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex flex-col items-center justify-center px-4 text-center">
      <div className="max-w-lg">
        <p className="text-sm font-medium uppercase tracking-widest text-indigo-300/90 mb-3">
          Bienvenido
        </p>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
          Tu espacio seguro
        </h1>
        <p className="text-lg text-slate-300 mb-10 leading-relaxed">
          Inicia sesión o crea una cuenta para acceder a tu perfil y gestionar
          tu cuenta.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/login"
            className="inline-flex items-center justify-center rounded-xl bg-white px-8 py-3.5 text-base font-semibold text-slate-900 shadow-xl transition hover:bg-slate-100 active:scale-[0.98]"
          >
            Iniciar sesión
          </Link>
          <Link
            to="/registro"
            className="inline-flex items-center justify-center rounded-xl border-2 border-white/30 bg-white/5 px-8 py-3.5 text-base font-semibold text-white backdrop-blur transition hover:bg-white/10 active:scale-[0.98]"
          >
            Registrarse
          </Link>
        </div>
      </div>
    </div>
  );
}
