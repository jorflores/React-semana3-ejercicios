import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function Perfil() {
  const navigate = useNavigate();
  const [usuario, setUsuario] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 1. Recuperamos el token que guardamos al hacer login
    const token = localStorage.getItem('token');

    // 2. Si no hay token, el usuario no está autenticado
    if (!token) {
      navigate('/login', { replace: true });
      return;
    }

    let cancelled = false;

    const load = async () => {
      setLoading(true);
      try {
        // 3. Enviamos el token en el header Authorization
        // El middleware verificarToken en el backend lo leerá desde aquí
        const res = await axios.get(
          import.meta.env.VITE_API_URL + '/api/usuarios/perfil',
          { headers: { Authorization: `Bearer ${token}` } }
        );
        if (!cancelled) setUsuario(res.data);
      } catch {
        localStorage.removeItem('token');
        navigate('/login', { replace: true });
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [navigate]);

  const handleLogout = () => {
    // 4. Logout: eliminamos el token y regresamos al login
    localStorage.removeItem('token');
    navigate('/login', { replace: true });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center p-4">
        <div className="rounded-2xl bg-white/10 px-8 py-6 text-white backdrop-blur">
          <p className="text-center font-medium">Cargando perfil…</p>
          <div className="mt-4 h-1 w-48 overflow-hidden rounded-full bg-white/20">
            <div className="h-full w-1/3 animate-pulse rounded-full bg-indigo-400" />
          </div>
        </div>
      </div>
    );
  }

  if (!usuario) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-2xl bg-white/95 p-8 shadow-2xl shadow-indigo-500/10 ring-1 ring-white/10 backdrop-blur">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-3xl font-bold text-white shadow-lg">
            {usuario.nombre?.charAt(0)?.toUpperCase() || '?'}
          </div>
          <h1 className="text-xl font-bold text-slate-900">Tu perfil</h1>
          <p className="text-sm text-slate-500">Datos de tu cuenta</p>
        </div>

        <dl className="space-y-4 rounded-xl border border-slate-100 bg-slate-50/80 p-5 text-left">
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Nombre
            </dt>
            <dd className="mt-1 text-lg font-medium text-slate-900">
              {usuario.nombre}
            </dd>
          </div>
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Email
            </dt>
            <dd className="mt-1 text-lg font-medium text-slate-900 break-all">
              {usuario.email}
            </dd>
          </div>
        </dl>

        <button
          type="button"
          onClick={handleLogout}
          className="mt-8 w-full rounded-xl border-2 border-slate-200 bg-white py-3.5 font-semibold text-slate-700 transition hover:bg-slate-50 active:scale-[0.98]"
        >
          Cerrar sesión
        </button>
      </div>
    </div>
  );
}
