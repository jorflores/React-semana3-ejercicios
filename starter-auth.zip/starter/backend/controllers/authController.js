const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Usuario = require('../models/Usuario');

exports.registro = async (req, res) => {
  const { nombre, email, password } = req.body;
  try {
    // TODO 1: Hashear el password con bcrypt (saltRounds: 10)

    // TODO 2: Crear el usuario en la BD con Usuario.create()
    //         Usar el password hasheado, no el original

    // TODO 3: Responder con status 201 y { mensaje: 'Usuario creado' }

  } catch (err) {
    res.status(400).json({ error: 'Error al crear usuario' });
  }
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    // TODO 4: Buscar el usuario por email con Usuario.findOne()

    // TODO 5: Si no existe, responder 401 { error: 'Credenciales inválidas' }

    // TODO 6: Comparar el password con bcrypt.compare()

    // TODO 7: Si no coincide, responder 401 { error: 'Credenciales inválidas' }

    // TODO 8: Firmar un JWT con { id, email } usando JWT_SECRET (expiry: '7d')

    // TODO 9: Responder con { token }

  } catch (err) {
    res.status(500).json({ error: 'Error del servidor' });
  }
};
