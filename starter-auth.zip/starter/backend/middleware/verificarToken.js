const jwt = require('jsonwebtoken');

const verificarToken = (req, res, next) => {
  // TODO 1: Extraer el token del header Authorization (formato: Bearer <token>)

  // TODO 2: Si no hay token, responder 401 { error: 'Token requerido' }

  // TODO 3: Verificar el token con jwt.verify() usando JWT_SECRET

  // TODO 4: Si es válido, guardar el payload en req.usuario y llamar next()

  // TODO 5: Si falla, responder 401 { error: 'Token inválido o expirado' }
};

module.exports = verificarToken;
