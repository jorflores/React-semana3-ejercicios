const router = require('express').Router();

router.get('/perfil', async (req, res) => {
  // TODO: Add verificarToken middleware to protect this route
  // TODO: Get the user id from req.usuario.id
  // TODO: Find user with Usuario.findByPk() returning only id, nombre, email
  res.json({ mensaje: 'Ruta no protegida aún' });
});

module.exports = router;
